<?php get_header(); ?>

<?php get_template_part( 'template-part', 'head' ); ?>

<!-- start content container -->
  <?php get_template_part( 'content', 'page' ); ?>
<!-- end content container -->

<?php get_footer(); ?>
